// Function to handle login
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission
    // Here you would normally handle authentication
    document.querySelector('.login').style.display = 'none';
    document.getElementById('deviceControl').style.display = 'block';
    document.getElementById('alertSection').style.display = 'block';
    populateItems(); // Load items after login
});

// Function to toggle device state (e.g., lights on/off)
function toggleDevice(device) {
    let deviceElement = document.getElementById(device);
    if (device === 'lights') {
        let currentState = deviceElement.classList.toggle('on');
        alert(currentState ? 'Lights turned ON' : 'Lights turned OFF');
    }
}

// Function to adjust thermostat temperature
function adjustTemp() {
    let tempRange = document.getElementById("tempRange").value;
    document.getElementById("tempValue").innerText = `${tempRange}°F`;
}

// Function to simulate viewing cameras
function viewCameras() {
    alert("Viewing security cameras...");
}

// Function to show alerts for unusual activities
function showAlert(message) {
    document.getElementById("alertMessage").innerText = message;
    alert(message);
}

// Simulate security alert after a few seconds
setTimeout(() => {
    showAlert("Motion detected at the front door!");
}, 10000);

// Function to populate items in the table
function populateItems() {
    const itemsList = document.getElementById('itemsList');
    const items = [
        { id: 1, name: 'Item 1' },
        { id: 2, name: 'Item 2' },
        { id: 3, name: 'Item 3' }
    ];

    items.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>
                <button class="action-btn" onclick="viewItem(${item.id})">View</button>
                <button class="action-btn" onclick="deleteItem(${item.id})">Delete</button>
            </td>
        `;
        itemsList.appendChild(row);
    });
}

// Function to view item details
function viewItem(id) {
    alert(`Viewing details for item ID: ${id}`);
}

// Function to delete an item
function deleteItem(id) {
    if (confirm(`Are you sure you want to delete item ID: ${id}?`)) {
        document.querySelector(`#itemsList tr:nth-child(${id})`).remove();
        alert(`Item ID: ${id} has been deleted.`);
    }
}

